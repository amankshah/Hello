import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
  let disposable = vscode.commands.registerCommand('runTestWithInput.run', async () => {
    const testName = await vscode.window.showInputBox({
      prompt: 'Enter test name to run',
      placeHolder: 'e.g. loginTest'
    });

    if (!testName) {
      vscode.window.showWarningMessage('Test name was not provided.');
      return;
    }

    const terminal = vscode.window.createTerminal('Run Test');
    terminal.show();
    terminal.sendText(`npm run test "${testName}"`);
  });

  const statusBarItem = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
  statusBarItem.command = 'runTestWithInput.run';
  statusBarItem.text = '$(play) Run Test';
  statusBarItem.tooltip = 'Click to run test with input';
  statusBarItem.show();
  context.subscriptions.push(statusBarItem);

  context.subscriptions.push(disposable);
}

export function deactivate() {}